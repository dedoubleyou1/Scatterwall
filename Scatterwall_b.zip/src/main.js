var game = new Phaser.Game(1080, 1920, Phaser.CANVAS, 'game', {
	preload: function() {
		// Preload loading bar images.
		// this.load.image('preloaderBg','images/preloaderBg.png');
        // this.load.image('preloaderBar', 'images/preloaderBar.png');
	},
	create: function() {
		this.game.stage.scale.pageAlignHorizontally = true;
		this.game.stage.scale.pageAlignVeritcally = true;
		this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;

		//this.game.stage.scale.refresh();
		this.state.add('Gameplay', Gameplay);

		this.state.start('Gameplay');
	}
});